from functools import wraps
from typing import Any, Callable
from ntdaisy.schema.nt import NTArgv

class NT:
    def __init__(self, config: NTArgv):
        self.nt_config = config

    def safe_execute(self, func:Callable[..., Any]|None=None, *, show_trace:bool=True) -> Any:
        """
        Decorator to safely execute functions with logging.
        Usage:
            @self.safe_execute
            def myfunc(): ...

            @self.safe_execute(show_trace=False)
            def myfunc(): ...
        """
        def decorator(f):
            @wraps(f)
            def wrapper(*args, **kwargs):
                try:
                    return f(*args, **kwargs)
                except Exception as e:
                    if show_trace:
                        self.nt_config.logger.exception(f"Exception in {f.__name__}: {e}")
                    else:
                        self.nt_config.logger.error(f"Exception in {f.__name__}: {e}")
                    return None
            return wrapper

        return decorator(func) if func else decorator
