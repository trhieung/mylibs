
import logging

from ntdaisy.schema.nt import *

class NTFormatter(logging.Formatter):
    def __init__(self, ntlog:NTLog, fmt:str|None=None, datefmt:str|None=None):
        super().__init__(fmt=fmt, datefmt=datefmt)
        self.ntlog = ntlog

    # Edit string log color
    def format(self, record):
        color = self.ntlog._COLOR_CODES.get(record.levelname, '')
        message = super().format(record)
        return f"{color}{message}{self.ntlog._RESET_CODE}"

def NTLog_to_Logger(ntlog:NTLog) -> logging.Logger:
    logger = logging.getLogger(ntlog.name)
    logger.setLevel(ntlog.level)

    if not logger.handlers:
        file_formatter:logging.Formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] %(name)s: %(message)s')
        console_formatter:logging.Formatter = NTFormatter(
            ntlog,
            fmt='[%(levelname)s] %(name)s: %(message)s'
        )

        if ntlog.file:
            ntlog.file.parent.mkdir(exist_ok=True)
            file_handler = logging.FileHandler(ntlog.file, encoding='utf-8')
            file_handler.setFormatter(file_formatter)
            logger.addHandler(file_handler)

        if ntlog.stream:
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(console_formatter)
            logger.addHandler(console_handler)

    if not (ntlog.file or ntlog.stream):
        print("Logging setup has no output handlers! You're wasting CPU cycles for nothing.")

    return logger
