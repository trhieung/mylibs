import sys

from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent.parent))
from ntdaisy.schema.nt import *
from ntdaisy.nt.core.v_1_0_0 import *
from ntdaisy.nt.handler.hdl_logger import *


class MyTask(NT):
    def __init__(self, config: NTArgv):
        super().__init__(config)

    def run(self) -> None:
        @self.safe_execute(show_trace=True)  # disable traceback in log
        def _run() -> None:
            print("Running risky code")
            raise ValueError("Oops")
        return _run()

task = MyTask(
    config=NTArgv(
        logger=NTLog_to_Logger(
            ntlog=NTLog(
                name="asdf",
                level=logging.DEBUG,
                file=Path(__file__).parent / "database/asdf.log",
                stream=True
            )
        )
    )
)

task.run()
print("hi")
