import sys

from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent.parent))
from ntdaisy.schema.nt import *
from ntdaisy.schema.nt_wheel_builder import *

from ntdaisy.nt.core.v_1_0_0 import *
from ntdaisy.nt.handler.hdl_logger import *

from ntdaisy.wheel_builder.core.v_1_0_0 import *


def ntdaisy_workspace():
    ntdaisy_dir = Path(__file__).parent.parent

    builder = NTWheelBuilder(
        config=NTWheelBuilderArgv(
            **NTWheelBuilderDir(
                dependencies=ntdaisy_dir/"dependencies",
                package=ntdaisy_dir,
                build=ntdaisy_dir/"sample/check_wheel_builder/build",
                release=ntdaisy_dir/"sample/check_wheel_builder/release",
                test=ntdaisy_dir/"sample/check_wheel_builder/test"
            ).model_dump(),
            python_version="3.11",
            logger=NTLog_to_Logger(
                ntlog=NTLog(
                    name="check_wheel_builder",
                    level=logging.DEBUG,
                    file=Path(__file__).parent / "database/check_wheel_builder.log",
                    stream=True
                )
            )
        )
    )
    
    # builder = NTWheelBuilder(
    #         config=NTWhellArgv(
    #     session_name="build_test",
    #     env=NTWheelEnvArgv(
    #         python_version="3.11",
    #         offline_pkgs=ntdaisy_dir/"offline_packages/windows/3.11",
    #         pkg_dir=ntdaisy_dir/"dev",
    #         build_dir=ntdaisy_dir/"prod/build",
    #         test_files={
    #             # ntdaisy_dir/"prod/usage/get_node.py": [],
    #             # ntdaisy_dir/"prod/usage/get_contact.py": [],
    #             ntdaisy_dir/"prod/usage/get_conversations.py": [],
    #             # ntdaisy_dir/"prod/usage/get_message_by_id.py": []
    #             # ntdaisy_dir/"prod/usage/get_messages_from_conversation.py": []
    #         },
    #         release_dir = ntdaisy_dir/"prod/release",
    #     ),
    #     noxdir=ntdaisy_dir/"prod/build/.nox",
    # ))

    builder.run()


ntdaisy_workspace()