import nox
import logging


from typing import Any
from pathlib import Path
import nox.sessions
from pydantic import BaseModel, ConfigDict
from pydantic import PrivateAttr, Field


class NTWheelBuilderDir(BaseModel):
    dependencies: Path
    package: Path
    build: Path
    release: Path
    test: Path

    _nox: Path = PrivateAttr()
    _build: Path = PrivateAttr()
    _dist: Path = PrivateAttr()
    _egg: Path = PrivateAttr()

    def model_post_init(self, context: Any) -> None:
        # Set up internal paths
        self._nox = self.build / ".nox"
        self._build = self.build / "build"
        self._dist = self.build / "dist"
        self._egg = self.build / "egg"

        # Create directories if they don't exist
        self.dependencies.mkdir(parents=True, exist_ok=True)
        self.package.mkdir(parents=True, exist_ok=True)
        self.build.mkdir(parents=True, exist_ok=True)
        self.release.mkdir(parents=True, exist_ok=True)
        self.test.mkdir(parents=True, exist_ok=True)

        self._nox.mkdir(parents=True, exist_ok=True)
        self._build.mkdir(parents=True, exist_ok=True)
        self._dist.mkdir(parents=True, exist_ok=True)
        self._egg.mkdir(parents=True, exist_ok=True)


class NTWheelBuilderTest(BaseModel):
    filename: str
    argv: list[str] = Field(default_factory=list)


class NTWheelBuilderArgv(NTWheelBuilderDir):
    python_version: str = "3.11"
    logger:logging.Logger
    tests: list[NTWheelBuilderTest] = Field(default_factory=list)

    _session_name: str = "build_test"

    def model_post_init(self, context: Any) -> None:
        super().model_post_init(context)

        # Check if all test files exist under self.test directory
        for t in self.tests:
            test_path = self.test / t.filename
            if not test_path.exists():
                raise FileNotFoundError(f"Test file not found: {test_path}")

    model_config = ConfigDict(
        arbitrary_types_allowed=True,
    )


class NTInstallerArgv(NTWheelBuilderArgv):
    session: nox.sessions.Session