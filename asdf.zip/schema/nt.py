import logging

from pathlib import Path
from pydantic import BaseModel, ConfigDict
from pydantic import model_validator, field_validator, PrivateAttr


class NTLog(BaseModel):
    name: str
    level: int
    file: Path | None = None
    stream: bool = False

    _COLOR_CODES: dict[str, str] = PrivateAttr()
    _RESET_CODE: str = PrivateAttr() 

    def model_post_init(self, __context=None):
        self._COLOR_CODES = {
            'DEBUG': '\033[94m',    # Blue
            'INFO': '\033[92m',     # Green
            'WARNING': '\033[93m',  # Yellow
            'ERROR': '\033[91m',    # Red
            'CRITICAL': '\033[95m', # Magenta
        }
        self._RESET_CODE = '\033[0m'


class NTArgv(BaseModel):
    logger:logging.Logger

    model_config = ConfigDict(
        arbitrary_types_allowed=True
    )