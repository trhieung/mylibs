import os
import nox
import json
import nox
import sys

from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent.parent.parent))
from ntdaisy.schema.nt import *
from ntdaisy.schema.nt_wheel_builder import *
from ntdaisy.nt.handler.hdl_logger import *
from ntdaisy.wheel_builder.handler.hdl_installer import *

# Dynamically set Python version from environment
python_version = os.environ.get("PYTHON_VERSION", "3.11")

@nox.session(python=python_version)
def build_test(session: nox.sessions.Session):
    
    nt_wheel_builder_argv = os.environ.get("NTWheelBuilderArgv", "")
    
    if not nt_wheel_builder_argv:
        print("[NTWheelBuilderArgv] Warning: NTWheelBuilderArgv not set. Skipping build.")
        return

    nt_wheel_builder_config = NTWheelBuilderArgv(
        **json.loads(nt_wheel_builder_argv),
        logger=NTLog_to_Logger(
            ntlog=NTLog(
                name="wheel_builder",
                level=logging.DEBUG,
                # file=Path(__file__).parent / "database/check_wheel_builder.log",
                stream=True
            )
        )
    )

    # Log all config
    print(f"📦 PKG_DIR                  = {nt_wheel_builder_config.package}")
    print(f"📦 BUILD_DIR                = {nt_wheel_builder_config.build}")
    print(f"📦 RELEASE_DIR              = {nt_wheel_builder_config.release}")
    print(f"📦 TEST_DIR                 = {nt_wheel_builder_config.test}")
    print(f"📄 DEPENDENCIES_DIR         = {nt_wheel_builder_config.dependencies}")
    print(f"🐍 PYTHON_VERSION           = {nt_wheel_builder_config.python_version}")
    print(f"📛 SESSION_NAME             = {session.name}")

    # Install and run
    nt_installer = NTInstaller(
        config = NTInstallerArgv(
            **nt_wheel_builder_config.model_dump(),
            session=session
        )
    )

    nt_installer.wheel_dependecies_install()
    nt_installer.wheel_build()
    nt_installer.wheel_install()
    nt_installer.wheel_test()
    nt_installer.wheel_release()
