import os
import shlex
import subprocess
import sys

from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent.parent.parent))
from ntdaisy.schema.nt import *
from ntdaisy.schema.nt_wheel_builder import *

from ntdaisy.nt.core.v_1_0_0 import *


class NTWheelBuilder(NT):
    def __init__(self, config: NTWheelBuilderArgv) -> None:
        super().__init__(
            config=NTArgv(
                logger=config.logger
            )
        )
        self.nt_wheel_builder_config = config
        self.noxfile = str(Path(__file__).parent / "noxfile.py")

    def run(self) -> None:
        @self.safe_execute(show_trace=True)
        def _run() -> None:
            cmd = [
                "nox",
                "--noxfile", self.noxfile,
                "--envdir", str(self.nt_wheel_builder_config._nox),
                "-s", self.nt_wheel_builder_config._session_name,
            ]

            # Safe logging with shlex
            self.nt_wheel_builder_config.logger.info(
                f"[NTWheelBuilder] Running: {' '.join(shlex.quote(arg) for arg in cmd)}"
            )

            # Prepare environment variables (placeholder)
            _env: dict[str, str] = dict(os.environ)
            _env["NTWheelBuilderArgv"] = self.nt_wheel_builder_config.model_dump_json(exclude={"logger"})

            subprocess.run(cmd, check=True, env=_env)

        return _run()
    
    