
import shutil
import sys

from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent.parent.parent))
from ntdaisy.nt.core.v_1_0_0 import *
from ntdaisy.schema.nt_wheel_builder import *
from ntdaisy.schema.nt import *


class NTInstaller(NT):
    def __init__(self, config:NTInstallerArgv):
        super().__init__(
            config=NTArgv(
                logger=config.logger
            )
        )
        self.nt_installer_config = config

        self._wheel_path: Path|None = None
        self._requirements_path: Path|None = None

    def _clean_artifacts(self) -> None:
        pass

    def _clean_pycache(self) -> None:
        # clean cache in package dir
        for pycache in self.nt_installer_config.package.rglob("__pycache__"):
            shutil.rmtree(pycache, ignore_errors=True)


    def _packages_requirements_sync(self, export: bool, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)

        if export:
            with open(path, "w") as f:
                self.nt_installer_config.session.run(
                    "pip", "list", "--format=freeze", external=True, stdout=f # use for out get pip list from main env
                    # "pip", "list", "--format=freeze", stdout=f
                )
        else:
            self.nt_installer_config.session.install("-r", str(path))

    def wheel_dependecies_install(self) -> None:
        """
        Install packages from wheel files located in subdirectories under `dependencies`.

        The structure is expected to be:
        dependencies/
        ├── build/
        │   └── *.whl
        ├── setuptools/
        │   └── *.whl
        └── ...

        Args:
            dependencies (Path): Path to the directory containing subfolders with wheel files.
        """
        if not self.nt_installer_config.dependencies.exists():
            raise FileNotFoundError(f"[Handler] Offline directory does not exist: {str(self.nt_installer_config.dependencies)}")

        for subdir in self.nt_installer_config.dependencies.iterdir():
            if subdir.is_dir():
                wheel_files = list(subdir.glob("*.whl"))
                if wheel_files:
                    self.nt_config.logger.info(f"\n📦 Installing wheels from: {subdir.name}")
                    for wheel in wheel_files:
                        self.nt_config.logger.info(f"  - {wheel.name}")

                    self.nt_installer_config.session.install(
                        "--no-index", 
                        "--find-links", 
                        str(subdir), *[str(w) for w in wheel_files],
                    )

    def wheel_build(self) -> Path|None:
        self._clean_pycache()

        @self.safe_execute(show_trace=True)
        def _wheel_build():
            # Ensure self.nt_installer_config.build.dist exists and is empty
            for item in self.nt_installer_config._dist.iterdir():
                if item.is_file():
                    item.unlink()
                elif item.is_dir():
                    shutil.rmtree(item)

            # Ensure egg and build directories exist
            self.nt_installer_config._egg.mkdir(parents=True, exist_ok=True)
            self.nt_installer_config._build.mkdir(parents=True, exist_ok=True)

            # Build the wheel using setup.py
            self.nt_installer_config.session.chdir(self.nt_installer_config.package)
            self.nt_installer_config.session.run(
                "python", "setup.py",
                "egg_info", f"--egg-base={self.nt_installer_config._egg}",
                "build", f"--build-base={self.nt_installer_config._build}",
                "bdist_wheel", f"--dist-dir={self.nt_installer_config._dist}",
            )

            # Collect and return the newest wheel
            wheels = list(self.nt_installer_config._dist.glob("*.whl"))
            if not wheels:
                self.nt_config.logger.error(f"No wheel was built in {self.nt_installer_config._dist}")
                return None

            self._wheel_path = max(wheels, key=lambda p: p.stat().st_mtime)
            return self._wheel_path
        
        return _wheel_build()
        
    def wheel_install(self) -> None:

        @self.safe_execute(show_trace=True)
        def _wheel_install() -> None:
            if self._wheel_path is None:
                return None
            if not self._wheel_path.exists():
                self.nt_config.logger.error(f"[Install] Wheel not found: {self._wheel_path}")
                return None
            self.nt_installer_config.session.install(str(self._wheel_path))

        return _wheel_install()

    def wheel_test(self) -> None:
        @self.safe_execute(show_trace=True)
        def _wheel_test():
            if not self.nt_installer_config.tests:
                self.nt_config.logger.info("[Test] No test files provided.")
                return
            
            for item in self.nt_installer_config.tests:
                self.nt_config.logger.info(
                    f"[Test] Running: {item.filename} {' '.join(item.argv)}"
                )
                self.nt_installer_config.session.run(
                    "python",
                    str(self.nt_installer_config.test / item.filename),
                    *item.argv
                )

        return _wheel_test()
    
    def wheel_release(self) -> None:
        @self.safe_execute(show_trace=True)
        def _wheel_release() -> None:
            release_dir = self.nt_installer_config.release
            dist_dir = self.nt_installer_config._dist
            package_dir = self.nt_installer_config.package

            # Ensure release folder exists
            release_dir.mkdir(parents=True, exist_ok=True)

            # Export requirements
            self._requirements_path = release_dir / "requirements.txt"
            self._packages_requirements_sync(export=True, path=self._requirements_path)

            # Clear and recreate src folder in one go
            dst_src_path = release_dir / "src"
            if dst_src_path.exists():
                shutil.rmtree(dst_src_path)
            shutil.copytree(package_dir, dst_src_path)

            # Clear and recreate release folder in one go
            dst_release = release_dir / "release"
            if dst_release.exists():
                shutil.rmtree(dst_release)
            dst_release.mkdir(parents=True, exist_ok=True)

            # Copy all wheels
            for wheel in dist_dir.glob("*.whl"):
                shutil.copy2(wheel, dst_release / wheel.name)

            self.nt_config.logger.info(f"[Release] Release created at {release_dir}")

        return _wheel_release()