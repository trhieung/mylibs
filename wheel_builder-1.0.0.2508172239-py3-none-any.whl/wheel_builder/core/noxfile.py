
from nox import sessions

import os
import nox
import json
import sys
import pathlib

sys.path.append(str(pathlib.Path(__file__).parent.parent.parent))
from wheel_builder.handler.nox_handler import NoxHandler
from wheel_builder.schema.wheel_builder_model import WheelBuilderHandlerModel


# Dynamically set Python version from environment
python_version = os.environ.get("PYTHON_VERSION", "3.11")

@nox.session(python=python_version)
def basic_build(session: sessions.Session):
    _nox_argv = os.environ.get("NoxArgv", "")
    
    if not _nox_argv:
        print("[NoxArgv] Warning: NoxArgv not set. Skipping build.")
        return

    nox_argv = WheelBuilderHandlerModel.NoxArgv(**json.loads(_nox_argv))

    # Log all config
    print(f"📦 PKG_DIR                  = {nox_argv.require_configuration.package.root}")
    print(f"📦 NOX_DIR                  = {nox_argv.require_configuration.nox.root}")
    print(f"📦 RELEASE_DIR              = {nox_argv.require_configuration.release.root}")
    print(f"📦 TEST_DIR                 = {nox_argv.require_configuration.test.root if nox_argv.require_configuration.test else None}")
    print(f"📄 DEPENDENCIES_DIR         = {nox_argv.dependencies}")
    print(f"🐍 PYTHON_VERSION           = {nox_argv.python_version}")
    print(f"📛 SESSION_NAME             = {nox_argv.session_name}")

    # Install and run
    nox_handler = NoxHandler(session=session, config=nox_argv)

    nox_handler.wheel_dependecies_install()
    nox_handler.wheel_build()
    nox_handler.wheel_release()
    nox_handler.wheel_install()
    nox_handler.wheel_test()
