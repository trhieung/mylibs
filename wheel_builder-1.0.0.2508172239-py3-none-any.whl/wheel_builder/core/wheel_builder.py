
import os
import shlex
import subprocess
import sys
import pathlib

sys.path.append(str(pathlib.Path(__file__).parent.parent.parent))
from wheel_builder.schema.wheel_builder_model import WheelBuilderModel, WheelBuilderHandlerModel


class WheelBuilder:
    def __init__(self, config: WheelBuilderModel.WheelBuilderArgv) -> None:
        self.config = config

    def run(self) -> None:
        _logger = self.config.logger

        @WheelBuilderHandlerModel.safe_execute(logger=_logger, show_trace=True)
        def _run() -> None:
            _noxfile = str(pathlib.Path(__file__).parent / "noxfile.py")
            cmd = [
                "nox",
                "--noxfile", _noxfile,
                "--envdir", str(self.config.require_configuration.nox._nox),
                "-s", self.config.session_name,
            ]

            # Safe logging with shlex
            self.config.logger.info(
                f"[NTWheelBuilder] Running: {' '.join(shlex.quote(arg) for arg in cmd)}"
            )

            # Prepare environment variables
            _env: dict[str, str] = dict(os.environ)
            # _env["PYTHON"] = "None" # tricky!
            _env["NoxArgv"] = WheelBuilderHandlerModel.NoxArgv(
                python_version=self.config.python_version,
                session_name=self.config.session_name,
                dependencies=self.config.dependencies,
                require_configuration=self.config.require_configuration
            ).model_dump_json()

            subprocess.run(cmd, check=True, env=_env)

        return _run()