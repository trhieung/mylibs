from nox import sessions

import shutil
import sys
import pathlib

sys.path.append(str(pathlib.Path(__file__).parent.parent.parent))
from wheel_builder.schema.wheel_builder_model import WheelBuilderModel, WheelBuilderHandlerModel
from wheel_builder.schema.nt_model import NT

class NoxHandler():
    def __init__(self, session:sessions.Session, config:WheelBuilderHandlerModel.NoxArgv):
        self._session = session
        self._config = config
        self._logger = NT.Logger.create_default_logger()
        

    def _clean_artifacts(self) -> None:
        pass

    def _clean_pycache(self) -> None:
        # clean cache in package dir
        for pycache in self._config.require_configuration.package.root.rglob("__pycache__"):
            shutil.rmtree(pycache, ignore_errors=True)

    def _packages_requirements_sync(self, export: bool, path: pathlib.Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)

        if export:
            self._logger.debug(f"[requirements] Export requirements in {str(path)}")
            with open(path, "w") as f:
                self._session.run(
                    "pip", "list", "--format=freeze", "--disable-pip-version-check", 
                    env={"PYTHONPATH": ""},
                    stdout=f,
                )
        else:
            self._session.install("-r", str(path))

    def wheel_dependecies_install(self) -> None:
        """
        Install packages from wheel files located in subdirectories under `dependencies`.

        The structure is expected to be:
        dependencies/
        ├── build/
        │   └── *.whl
        ├── setuptools/
        │   └── *.whl
        └── ...

        Args:
            dependencies (Path): Path to the directory containing subfolders with wheel files.
        """
        _dependencies = self._config.dependencies
        if not _dependencies.exists():
            raise FileNotFoundError(f"[Handler] Offline directory does not exist: {str(_dependencies)}")

        for subdir in _dependencies.iterdir():
            if subdir.is_dir():
                wheel_files = list(subdir.glob("*.whl"))
                if wheel_files:
                    self._logger.info(f"\n📦 Installing wheels from: {subdir.name}")
                    for wheel in wheel_files:
                        self._logger.info(f"  - {wheel.name}")

                    self._session.install(
                        "--no-index", 
                        "--find-links", 
                        str(subdir), *[str(w) for w in wheel_files],
                    )

    def wheel_build(self):
        """Build wheel and update self._config.require_configuration.release._wheel_path"""
        self._clean_pycache()

        @WheelBuilderHandlerModel.safe_execute(logger=self._logger, show_trace=True)
        def _wheel_build():
            # Ensure dist is empty
            dist_dir = self._config.require_configuration.nox._dist
            for item in dist_dir.iterdir():
                if item.is_file():
                    item.unlink()
                elif item.is_dir():
                    shutil.rmtree(item)

            # Ensure egg and build directories exist
            self._config.require_configuration.nox._egg.mkdir(parents=True, exist_ok=True)
            self._config.require_configuration.nox._build.mkdir(parents=True, exist_ok=True)

            # Prepare paths
            package_dir = self._config.require_configuration.package.root
            package_name = package_dir.name
            tmp_folder = self._config.require_configuration.nox._tmp

            # Reset tmp folder
            if tmp_folder.exists():
                shutil.rmtree(tmp_folder)
            tmp_pkg_dir = tmp_folder / package_name
            tmp_pkg_dir.mkdir(parents=True, exist_ok=True)

            # Copy only selected release folders
            selected = self._config.require_configuration.package.selected_for_release
            for folder in selected:
                src = package_dir / folder
                dst = tmp_pkg_dir / folder
                if src.exists():
                    shutil.copytree(src, dst)

            # Copy all top-level files (not folders) from package_dir
            for file in package_dir.iterdir():
                if file.is_file():
                    shutil.copy2(file, tmp_pkg_dir / file.name)

            # Copy setup.py
            shutil.copy2(self._config.require_configuration.nox._setup_py, tmp_folder / "setup.py")

            # Run build inside tmp
            self._session.chdir(tmp_folder)
            self._session.run(
                "python", "setup.py",
                "egg_info", f"--egg-base={self._config.require_configuration.nox._egg}",
                "build", f"--build-base={self._config.require_configuration.nox._build}",
                "bdist_wheel", f"--dist-dir={dist_dir}",
                f"--release-folders={','.join(selected)}",
                f"--release-name={package_name}",
            )

            # Collect newest wheel
            wheels = list(dist_dir.glob("*.whl"))
            if not wheels:
                self._logger.error(f"No wheel was built in {dist_dir}")
                return None

            newest_wheel = max(wheels, key=lambda p: p.stat().st_mtime)
            self._config.require_configuration.release._wheel_path = newest_wheel
            return newest_wheel

        return _wheel_build()

    def wheel_install(self) -> None:

        @WheelBuilderHandlerModel.safe_execute(logger=self._logger, show_trace=True)
        def _wheel_install() -> None:
            _wheel_path = self._config.require_configuration.release._wheel_path
            if _wheel_path is None:
                return None
            if not _wheel_path.exists():
                self._logger.error(f"[Install] Wheel not found: {_wheel_path}")
                return None
            self._session.install(str(_wheel_path))

        return _wheel_install()

    def wheel_test(self) -> None:
        @WheelBuilderHandlerModel.safe_execute(logger=self._logger, show_trace=True)
        def _wheel_test():
            test_dir = self._config.require_configuration.test 
            if not test_dir:
                self._logger.info("[Test] No test files provided.")
                return
            
            for file in test_dir.files:
                self._logger.info(
                    f"[Test] Running: {file.filename} {' '.join(file.argv)}"
                )
                self._session.run(
                    "python",
                    str(test_dir.root / file.filename),
                    *file.argv
                )

        return _wheel_test()
    
    def wheel_release(self) -> None:
        @WheelBuilderHandlerModel.safe_execute(logger=self._logger, show_trace=True)
        def _wheel_release() -> None:
            nox_dir = self._config.require_configuration.nox
            release_dir = self._config.require_configuration.release

            # Export requirements
            self._packages_requirements_sync(export=True, path=release_dir._requirements_file)

            # --- Copy source package ---
            src_package = nox_dir._tmp
            dst_package = release_dir._source

            # Reset dst_package completely
            if dst_package.exists():
                shutil.rmtree(dst_package)
            dst_package.mkdir(parents=True, exist_ok=True)

            # Copy everything from src -> dst (files + folders)
            for item in src_package.iterdir():
                dst_item = dst_package / item.name
                if item.is_dir():
                    shutil.copytree(item, dst_item)
                else:
                    shutil.copy2(item, dst_item)

            # --- Copy wheel file ---
            src_whl = release_dir._wheel_path   # single .whl file
            dst_whl_dir = release_dir._release  # folder

            if not src_whl or not src_whl.exists():
                self._logger.critical("No built wheel file found. Did you run wheel_build()?")
                return None

            # Reset release folder
            if dst_whl_dir.exists():
                shutil.rmtree(dst_whl_dir)
            dst_whl_dir.mkdir(parents=True, exist_ok=True)

            # Copy wheel into release folder
            dst_whl = dst_whl_dir / src_whl.name
            shutil.copy2(src_whl, dst_whl)

            # --- Copy tests ---
            if self._config.require_configuration.test:
                src_test = self._config.require_configuration.test.root
                dst_test = release_dir._usage

                if dst_test.exists():
                    shutil.rmtree(dst_test)
                dst_test.mkdir(parents=True, exist_ok=True)

                for item in src_test.iterdir():
                    dst_item = dst_test / item.name
                    if item.is_file() and item.suffix == ".py":
                        shutil.copy2(item, dst_item)
                    elif item.is_dir():
                        # copy all .py files from subfolders too
                        shutil.copytree(
                            item, dst_item,
                            ignore=shutil.ignore_patterns("*", "!*.py")
                        )

            self._logger.info(f"[Release] Release created at {release_dir}")

        return _wheel_release()
