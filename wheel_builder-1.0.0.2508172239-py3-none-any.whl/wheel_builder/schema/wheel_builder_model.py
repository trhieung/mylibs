
import logging
import pydantic
import pathlib
import typing
import sys
import functools

sys.path.append(str(pathlib.Path(__file__).parent))
from nt_model import NT

class WheelBuilderHandlerModel:
    class PathConfiguration:
        class NoxDir(pydantic.BaseModel):
            root: pathlib.Path

            REL_NOX: typing.ClassVar[str] = ".nox"
            REL_BUILD: typing.ClassVar[str] = "build"
            REL_DIST: typing.ClassVar[str] = "dist"
            REL_EGG: typing.ClassVar[str] = "egg"
            REL_TMP: typing.ClassVar[str] = "tmp"

            _nox: pathlib.Path = pydantic.PrivateAttr()
            _build: pathlib.Path = pydantic.PrivateAttr()
            _dist: pathlib.Path = pydantic.PrivateAttr()
            _egg: pathlib.Path = pydantic.PrivateAttr()
            _tmp: pathlib.Path = pydantic.PrivateAttr()

            _setup_py: pathlib.Path = pydantic.PrivateAttr()

            def model_post_init(self, context: typing.Any) -> None:
                self.root.mkdir(parents=True, exist_ok=True)
                
                self._nox = self.root / self.REL_NOX
                self._build = self.root / self.REL_BUILD
                self._dist = self.root / self.REL_DIST
                self._egg = self.root / self.REL_EGG
                self._tmp = self.root / self.REL_TMP

                self._nox.mkdir(parents=True, exist_ok=True)
                self._build.mkdir(parents=True, exist_ok=True)
                self._dist.mkdir(parents=True, exist_ok=True)
                self._egg.mkdir(parents=True, exist_ok=True)
                self._tmp.mkdir(parents=True, exist_ok=True)

                self._setup_py = pathlib.Path(__file__).parent.parent / "data" / "setup.py"

                if not self._setup_py.exists():
                    raise FileNotFoundError(f"Required setup.py not found at {self._setup_py}")

        class PackageDir(pydantic.BaseModel):
            root: pathlib.Path
            selected_for_release: list[str] = pydantic.Field(default_factory=list)

            def model_post_init(self, __context: typing.Any) -> None:
                # Ensure root exists
                self.root.mkdir(parents=True, exist_ok=True)

                # If still empty, auto-fill with folder names
                if not self.selected_for_release:
                    self.selected_for_release = [
                        p.name for p in self.root.iterdir() if p.is_dir()
                    ]

        class ReleaseDir(pydantic.BaseModel):
            root: pathlib.Path
            
            REL_RELEASE: typing.ClassVar[str] = "release"
            REL_USAGE: typing.ClassVar[str] = "usage"
            REL_SOURCE: typing.ClassVar[str] = "source"


            _release: pathlib.Path = pydantic.PrivateAttr() # where wheel file placed
            _usage: pathlib.Path = pydantic.PrivateAttr()
            _source: pathlib.Path = pydantic.PrivateAttr()

            _wheel_path: pathlib.Path|None = pydantic.PrivateAttr() # update after release
            _requirements_file: pathlib.Path = pydantic.PrivateAttr()
            
            def model_post_init(self, context: typing.Any) -> None:
                self.root.mkdir(parents=True, exist_ok=True)
            
                self._release = self.root / self.REL_RELEASE
                self._usage = self.root / self.REL_USAGE
                self._source = self.root / self.REL_SOURCE

                self._release.mkdir(parents=True, exist_ok=True)
                self._usage.mkdir(parents=True, exist_ok=True)
                self._source.mkdir(parents=True, exist_ok=True)

                self._requirements_file = self.root / "requirements.txt"

        class TestDir(pydantic.BaseModel):
            class RunOPT(pydantic.BaseModel):
                filename: str
                argv: list[str] = pydantic.Field(default_factory=list)

            root: pathlib.Path
            files: list[RunOPT]
            
            def model_post_init(self, context: typing.Any) -> None:
                for file in self.files:
                    # Must end with .py
                    if pathlib.Path(file.filename).suffix != ".py":
                        raise ValueError(f"Invalid file type: {file.filename} (must be .py)")

                    # Must exist inside root
                    file_abs_path = self.root / file.filename
                    if not file_abs_path.exists():
                        raise FileNotFoundError(f"File not found: {file_abs_path}")

    class NoxArgv(pydantic.BaseModel):
        class RequireConfig(pydantic.BaseModel):
            nox: "WheelBuilderHandlerModel.PathConfiguration.NoxDir"
            package: "WheelBuilderHandlerModel.PathConfiguration.PackageDir"
            release: "WheelBuilderHandlerModel.PathConfiguration.ReleaseDir"
            test: typing.Optional["WheelBuilderHandlerModel.PathConfiguration.TestDir"]

        python_version: str = "3.11"
        session_name: str = "basic_build"
        dependencies: pathlib.Path
        require_configuration: RequireConfig

        VALIDED_SESSION_NAME: typing.ClassVar[list[str]] = ["basic_build"]

        def model_post_init(self, context: typing.Any) -> None:
            """
            Note for next update:
                dependencies: 
                    + pathlib.Path: for offline packages
                    + str: requirements.txt for online install
            """
            if self.session_name not in self.VALIDED_SESSION_NAME:
                raise ValueError(
                    f"Invalid session_name '{self.session_name}', "
                    f"must be one of {self.VALIDED_SESSION_NAME}"
                )

    # =================== staticmethod =================== 
    @staticmethod
    def safe_execute(
        func:typing.Callable[..., typing.Any]|None=None, 
        *, 
        logger:logging.Logger, 
        show_trace:bool=True
        ) -> typing.Any:
        def decorator(f):
            @functools.wraps(f)
            def wrapper(*args, **kwargs):
                try:
                    return f(*args, **kwargs)
                except Exception as e:
                    if show_trace:
                        logger.exception(f"Exception in {f.__name__}: {e}")
                    else:
                        logger.error(f"Exception in {f.__name__}: {e}")
                    return None
            return wrapper

        return decorator(func) if func else decorator


class WheelBuilderModel: # Release    
    class WheelBuilderArgv(WheelBuilderHandlerModel.NoxArgv):
        logger:logging.Logger

        model_config = pydantic.ConfigDict(arbitrary_types_allowed=True)

WheelBuilderModel.WheelBuilderArgv.model_rebuild()
WheelBuilderHandlerModel.NoxArgv.model_rebuild()

##############################################
