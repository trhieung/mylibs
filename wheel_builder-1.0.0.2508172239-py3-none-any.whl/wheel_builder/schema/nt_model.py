
import pydantic
import logging
import pathlib
from urllib import parse

class NT:
    class Proxy(pydantic.BaseModel):
        proxy_url: str

        _host: str = pydantic.PrivateAttr()
        _port: int = pydantic.PrivateAttr()
        _scheme: str = pydantic.PrivateAttr()
        _auth: tuple[str, str] | None = pydantic.PrivateAttr()

        model_config = pydantic.ConfigDict(
            str_strip_whitespace=True
        )
        def model_post_init(self, context):
            parsed = parse.urlparse(self.proxy_url)

            if not parsed.scheme or not parsed.hostname or not parsed.port:
                raise ValueError(f"Invalid proxy string: {self.proxy_url}")

            self._scheme = parsed.scheme
            self._host = parsed.hostname
            self._port = parsed.port

            username = parse.unquote(parsed.username) if parsed.username else None
            password = parse.unquote(parsed.password) if parsed.password else None
            self._auth = (username, password) if username and password else None

        def parse_for_rest_service(self):
            return {
                "http": self.proxy_url,
                "https": self.proxy_url,
            }
        
        def parse_for_websocket_service(self):
            return {
                "http_proxy_host": self._host,
                "http_proxy_port": self._port,
                "proxy_type": self._scheme,
                "http_proxy_auth": self._auth
            }
        
    class Logger(pydantic.BaseModel):
        pass
    
        @staticmethod
        def create_default_logger() -> logging.Logger:
            logger = logging.getLogger("app")
            logger.setLevel(logging.INFO)

            if not logger.handlers:  # Avoid duplicate handlers
                handler = logging.StreamHandler()
                formatter = logging.Formatter(
                    fmt="[%(asctime)s] [%(levelname)s] %(name)s: %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S",
                )
                handler.setFormatter(formatter)
                logger.addHandler(handler)

            return logger