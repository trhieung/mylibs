
import sys
import pathlib

sys.path.append(str(pathlib.Path(__file__).parent.parent.parent))
from wheel_builder.core.wheel_builder import WheelBuilder
from wheel_builder.schema.wheel_builder_model import WheelBuilderModel, WheelBuilderHandlerModel
from wheel_builder.schema.nt_model import NT

def wheel_builder_workspace():
    _package_dir = pathlib.Path(__file__).parent.parent
    _dependencies = _package_dir.parent / "_dependencies/ubuntu/discord_api_3.11"

    _sample_dir = _package_dir / "_sample"
    _database_dir = _package_dir / "_database"
    _nox_build_dir = _package_dir/"_nox_build"

    _test_dir = _sample_dir / "test"

    builder = WheelBuilder(
        config = WheelBuilderModel.WheelBuilderArgv(
            dependencies=_dependencies,
            require_configuration=WheelBuilderHandlerModel.NoxArgv.RequireConfig(
                nox=WheelBuilderHandlerModel.PathConfiguration.NoxDir(root=_nox_build_dir),
                release=WheelBuilderHandlerModel.PathConfiguration.ReleaseDir(root=_sample_dir/"release"),
                package=WheelBuilderHandlerModel.PathConfiguration.PackageDir(
                    root=_package_dir,
                    selected_for_release=["core", "schema", "data", "handler"]
                ),
                test=WheelBuilderHandlerModel.PathConfiguration.TestDir(
                    root=_test_dir,
                    files=[
                        WheelBuilderHandlerModel.PathConfiguration.TestDir.RunOPT(filename="get_node.py", argv=[]),
                        # WheelBuilderHandlerModel.PathConfiguration.TestDir.RunOPT(filename="x.py", argv=[])
                    ]
                )
            ),
            logger=NT.Logger.create_default_logger()
        )
    )

    builder.run()


wheel_builder_workspace()