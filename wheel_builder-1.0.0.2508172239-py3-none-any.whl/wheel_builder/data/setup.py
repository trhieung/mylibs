# Copyright 2017 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import sys
from pathlib import Path
from datetime import datetime
from typing import Any
from setuptools import setup, find_packages


def get_arg_value(tag: str, cast=lambda x: x, required: bool = True) -> Any:
    """
    Extracts an argument value from sys.argv using --tag=value format.

    Args:
        tag (str): The argument name without '--'.
        cast (callable): A function to convert the value.
        required (bool): Whether this argument is mandatory.

    Returns:
        The casted value or None.

    Raises:
        SystemExit: If required is True and the argument is missing.
    """
    for arg in sys.argv:
        if arg.startswith(f"--{tag}="):
            value = arg.split("=", 1)[1]
            sys.argv.remove(arg)
            return cast(value)

    if required:
        sys.exit(f"[ERROR] You must specify --{tag}=<value>")
    return None


# Get arguments
release_folders:list[str] = get_arg_value("release-folders", cast=lambda v: v.split(","))
project_name:str = get_arg_value("release-name", cast=str)

# Ensure at least one directory exists
package_dir = Path(__file__).parent / project_name
existing_folders = [
    name for name in release_folders 
    if (package_dir / name).exists()
]
if not existing_folders:
    sys.exit(f"[ERROR] None of the release directories exist: {release_folders}")

# Generate version like 1.0.0.2506041530 (DDMMYYHHMM)
date_version = datetime.now().strftime("%y%m%d%H%M")
VERSION = f"1.0.0.{date_version}"

setup(
    name=project_name,
    version=VERSION,
    description='',
    long_description='',
    license='',

    packages=find_packages(),
    package_data={
        project_name: [
            pattern
            for d in existing_folders
            for pattern in (f'{d}/**/**/*', f'{d}/**/*')
        ]
    },
    zip_safe=False,
)
