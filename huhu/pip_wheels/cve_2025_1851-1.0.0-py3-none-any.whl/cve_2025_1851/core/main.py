
PROJECT_NAME = 'cve_2025_1851'

def run_poc():
    print(f'Hi from runpoc of {PROJECT_NAME}')