from .main import run_poc

# Enviroment variables
CVE_NAME = 'cve_2025_1851'