def foo():
    print("foo from module A")