# from .main import *
from .prod import *


# Enviroment variables
PROJECT_NAME = 'glucus'