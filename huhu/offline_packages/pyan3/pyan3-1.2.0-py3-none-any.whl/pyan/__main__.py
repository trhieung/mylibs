# -*- coding: utf-8 -*-

import pyan

if __name__ == "__main__":
    pyan.main()
